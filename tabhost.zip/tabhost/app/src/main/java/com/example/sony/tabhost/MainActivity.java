package com.example.sony.tabhost;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.TabLayout;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.URI;
import java.util.Objects;
import java.util.concurrent.Semaphore;

public class MainActivity extends AppCompatActivity {

    private static final String KEY_VERIFY_IN_PROGRESS = "key_verify_in_progress";
    private boolean mVerificationInProgress = false;
    private StorageReference storageReference;
    private static final  int GALLERY_INTENT = 1;
    private TextView mTextMessage;
    String profileImageUrl;
    private ImageView profileimageView ;
    ProgressBar progressbar1;
    FirebaseAuth auth;
    FragmentManager fragmentManager = getSupportFragmentManager();
    Notification_fragment notification_fragment = new Notification_fragment();
    Profile_fragment profile_fragment = new Profile_fragment();
    Message_fragment message_fragment = new Message_fragment();
    Trajets_Fragment trajets_fragment = new Trajets_Fragment();
    //array of strings used to populate the spinner
    final String[] spin = {"","Change Profile Picture","Delete Profile picture"};


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            switch (item.getItemId()) {
                case R.id.navigation_home:
                fragmentManager.beginTransaction().replace(R.id.frameLayout,
                        trajets_fragment,
                        trajets_fragment.getTag()).commit();
                return true;

                case R.id.message:
                fragmentManager.beginTransaction().replace(R.id.frameLayout,
                        message_fragment,
                        message_fragment.getTag()).commit();

                    return true;


                case R.id.navigation_notifications:
                    fragmentManager.beginTransaction().replace(R.id.frameLayout,
                            notification_fragment,
                            notification_fragment.getTag()).commit();
                    return true;

                case R.id.profile:
                    fragmentManager.beginTransaction().replace(R.id.frameLayout,
                            profile_fragment,
                            profile_fragment.getTag()).commit();
                    return true;

            }
            return false;
        }
    };


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(KEY_VERIFY_IN_PROGRESS, mVerificationInProgress);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mVerificationInProgress = savedInstanceState.getBoolean(KEY_VERIFY_IN_PROGRESS);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            onRestoreInstanceState(savedInstanceState);}

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        //profile fragment attributes
       profileimageView  =(ImageView) findViewById(R.id.profileimage);
       storageReference= FirebaseStorage.getInstance().getReference();
       progressbar1= (ProgressBar) findViewById(R.id.progressBar1);
        auth = FirebaseAuth.getInstance();
        FirebaseUser user3 = auth.getCurrentUser();
        fragmentManager.beginTransaction().replace(R.id.frameLayout,
                trajets_fragment,
                trajets_fragment.getTag()).commit();

    }


    // profile fragment
  public  void logout (View view) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.signOut();
        Toast.makeText(this, "Logout succesfull", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this,LoginActivity.class));
        finish();


    }
  public void upload_photo(View view) {

        final Spinner spinner = (Spinner) findViewById(R.id.addpic);
        spinner.performClick();

        // Create an ArrayAdapter using the string array and a default spinner layout
        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Add_pic, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        //Register a callback to be invoked when an item in this AdapterView has been selected


        spinner.setOnItemSelectedListener (new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinner.setSelection( 0 );
                String valuespin= "";
                  valuespin = spin[position];
                switch ( position ) {
                    case 1:
                        progressbar1= (ProgressBar) findViewById(R.id.progressBar1);
                        Intent intent = new Intent(Intent.ACTION_PICK);
                        intent.setType("image/*");
                        progressbar1.setVisibility(View.VISIBLE);
                        startActivityForResult(intent,GALLERY_INTENT);
                        break;
                    case 2:
                        progressbar1= (ProgressBar) findViewById(R.id.progressBar1);
                        progressbar1.setVisibility(View.VISIBLE);
                        deletephotoprofile();
                        break;

                    default:
                        break;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"nothing",Toast.LENGTH_SHORT).show();
               }});
    }
  @Override
  protected void onActivityResult(int requestCode, int resultCode, final Intent data) {

        progressbar1= findViewById(R.id.progressBar1);
        profileimageView  = findViewById(R.id.profileimage);
        storageReference= FirebaseStorage.getInstance().getReference();
        if (requestCode == GALLERY_INTENT & resultCode == RESULT_OK && data != null && data.getData()!=null) {
            final Uri uriprofileimage = data.getData();

            StorageReference filepath = storageReference.child("photos").child(uriprofileimage.getLastPathSegment());
            filepath.putFile(uriprofileimage).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    //download the pic before set it in the imageview
                    auth = FirebaseAuth.getInstance();
                    final FirebaseUser user=auth.getCurrentUser();
                    profileImageUrl=taskSnapshot.getDownloadUrl().toString();
                    UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder()
                            .setPhotoUri(Uri.parse(profileImageUrl)).build();
                    assert user != null;
                    user.updateProfile(profileUpdate)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()){
                                        //Set the uri in the realtime
                                        final Uri uri =   user.getPhotoUrl();
                                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                                        final DatabaseReference ref = database.getReference();
                                        final DatabaseReference reference = database.getReference();
                                        FirebaseUser user=auth.getCurrentUser();
                                        assert user != null;
                                        String username = user.getDisplayName();
                                        ref.child("User").orderByChild("fullName").equalTo(username).addChildEventListener(new ChildEventListener() {
                                            @Override
                                            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                                                String Uid= dataSnapshot.getKey();
                                                reference.child("User").child(Uid).child("photo_profile").setValue(uri.toString());}
                                            @Override
                                            public void onChildChanged(DataSnapshot dataSnapshot, String s) {}
                                            @Override
                                            public void onChildRemoved(DataSnapshot dataSnapshot) {}
                                            @Override
                                            public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {
                                                Toast.makeText(getApplicationContext(),"probleme",Toast.LENGTH_SHORT).show();
                                            }});
                                        Picasso.with(MainActivity.this).load(uri).into(profileimageView);
                                        progressbar1.setVisibility(View.GONE);
                                        Toast.makeText(MainActivity.this,"image successfully uploaded ",Toast.LENGTH_LONG).show();

                                    }
                                }
                            });
                }
            });


        }

    }
  private void deletephotoprofile() {
        //Delete photo from Storge and real time and Firebaseuser and the imagview

      progressbar1= (ProgressBar) findViewById(R.id.progressBar1);
progressbar1.setVisibility(View.VISIBLE);
      profileimageView  =(ImageView) findViewById(R.id.profileimage);
      storageReference= FirebaseStorage.getInstance().getReference();
      final FirebaseDatabase database = FirebaseDatabase.getInstance();
      DatabaseReference ref1 = database.getReference();
      final DatabaseReference ref2 = database.getReference();
      auth = FirebaseAuth.getInstance();
      FirebaseUser user=auth.getCurrentUser();
      assert user != null;
      String username = user.getDisplayName();

ref1.child("User").orderByChild("fullName").equalTo(username).addChildEventListener(new ChildEventListener() {
    @Override
    public void onChildAdded(DataSnapshot dataSnapshot, String s) {
        ref2.child("User").child(dataSnapshot.getKey().toString()).child("photo_profile").setValue("vide");
        profileimageView.setImageResource(R.drawable.profile_vide);
        progressbar1.setVisibility(View.GONE);
     }
    @Override
    public void onChildChanged(DataSnapshot dataSnapshot, String s) {}
    @Override
    public void onChildRemoved(DataSnapshot dataSnapshot) {}
    @Override
    public void onChildMoved(DataSnapshot dataSnapshot, String s) {}
    @Override
    public void onCancelled(DatabaseError databaseError) {}});


    }


    public void gotoappseting(View view) {
        startActivity(new Intent(getApplication(),AppSetting.class));
    }
    public void gotoaccountsetting(View view) {
        startActivity(new Intent(getApplication(),AccountSetting.class));
    }
    public void gotofriends(View view) {
        startActivity(new Intent(getApplication(),Friends.class));
    }
    public void gotomycars(View view) {
        startActivity(new Intent(getApplication(),Mycars.class));
    }




// Trajets Fragments

    public  void AddTrip (View view) {


    }

    public  void Search_A_trip (View view) {


    }



















}


