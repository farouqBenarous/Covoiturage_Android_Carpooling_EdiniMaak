package com.example.sony.tabhost;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.util.Set;

public class Mycars extends AppCompatActivity {
     FirebaseDatabase database ;
     DatabaseReference ref;
     FirebaseAuth auth;
     FirebaseStorage storage;
    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycars);
        storage = FirebaseStorage.getInstance();
        database = FirebaseDatabase.getInstance();
        ref = database.getReference();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

    }


    public void addcar(View view) {
        startActivity(new Intent(getApplication(),Setinformationcar.class));

    }
}
