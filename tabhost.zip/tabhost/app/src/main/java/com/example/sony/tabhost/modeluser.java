

package com.example.sony.tabhost;

import com.google.firebase.database.Exclude;

/**
 * Created by Sony on 27/12/2017.
 */

public class modeluser {

    private String email;
    private String fullname;
    private String gender;
    private String age;
    private String photo_profile;
    private String Phone_number;
    private String cars;


    public modeluser(String email, String fullname, String gender, String age, String Phone_number, String photo_profile, String cars) {
        this.email = email;
        this.fullname = fullname;
        this.gender = gender;
        this.age = age;
        this.Phone_number = Phone_number;
        this.photo_profile = photo_profile;
        this.cars = cars;

    }

    public modeluser(String email, String fullname, String gender, String age, String Phone_number) {
        this.email = email;
        this.fullname = fullname;
        this.gender = gender;
        this.age = age;
        this.Phone_number = Phone_number;
    }


    public modeluser(String email, String fullname, String gender, String age) {
        this.email = email;
        this.fullname = fullname;
        this.gender = gender;
        this.age = age;
    }


    public modeluser() {
    }


    public String getfullName() {
        return fullname;
    }

    public void setfullName(String fullname) {
        this.fullname = fullname;
    }

    public String getPhoto_profile() {
        return photo_profile;
    }

    public void setPhoto_profile(String photo_profile) {
        this.photo_profile = photo_profile;
    }


    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone_number() {
        return Phone_number;
    }

    public void setPhone_number(String phone_number) {
        Phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCars() {
        return cars;
    }

    public void setCars(String cars) {
        this.cars = cars;
    }
}
